package com.example.listviewcaller;

import java.util.ArrayList;

import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends Activity {

	ListView lv;
	ArrayList<Contact> list = new ArrayList<Contact>();
	ItemAdapter adapter;
	AdapterView.AdapterContextMenuInfo info;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.lv=(ListView)this.findViewById(R.id.listView1);
        
        
        list.add(new Contact(R.drawable.img9,"Pakot","0926630364"));
        list.add(new Contact(R.drawable.img8,"Marcos","0341487641"));
        list.add(new Contact(R.drawable.img7,"Meriam","465473165"));
        list.add(new Contact(R.drawable.img6,"Pinoy","2454513654"));
        list.add(new Contact(R.drawable.img5,"Du30","911"));
        list.add(new Contact(R.drawable.img4,"Binay","013484684"));
        list.add(new Contact(R.drawable.img3,"Roxas","13549843"));
        this.adapter=new ItemAdapter(this,list);
        
        this.lv.setAdapter(adapter);
        
        this.registerForContextMenu(lv);
        
    }

	@Override
	public boolean onContextItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		int id = item.getItemId();
		switch(id){
		case R.id.view:
			ImageView iv = new ImageView (this);
			TextView lblname = new TextView(this);
			TextView lbltel = new TextView(this);
			
			iv.setImageResource(list.get(info.position).getImage());
			lblname.setText(list.get(info.position).getName());
			lblname.setPadding(10, 10, 10, 10);
			lbltel.setText(list.get(info.position).getTel());
			lbltel.setPadding(10, 10, 10, 10);
			LinearLayout layout = new LinearLayout(this);
			layout.setOrientation(LinearLayout.HORIZONTAL);
			layout.addView(iv);
			layout.addView(lblname);
			layout.addView(lbltel);
			
			AlertDialog.Builder b = new AlertDialog.Builder(this);
			b.setTitle("Selected Contact");
			b.setIcon(R.drawable.ic_launcher);
			b.setView(layout);
			b.setNeutralButton("OK",null);
			
			AlertDialog dialog = b.create();
			dialog.show();
			
			break;
		case R.id.call:
			
			String telephone = list.get(info.position).getTel();
			Uri uri = Uri.parse("tel: " + telephone);
			Intent intent = new Intent(Intent.ACTION_CALL,uri);
			this.startActivity(intent);
			break;
		case R.id.send:
			Intent i = new Intent(Intent.ACTION_VIEW);
			i.putExtra("address",list.get(info.position).getTel());
			i.putExtra("sms_body","");
			i.setType("vnd.android-dir/mms-sms");
			this.startActivity(i);
			
		}
		
		return super.onContextItemSelected(item);
	}

	@Override
	public void onCreateContextMenu(ContextMenu menu, View v,
			ContextMenuInfo menuInfo) {
		// TODO Auto-generated method stub
		super.onCreateContextMenu(menu, v, menuInfo);
		 getMenuInflater().inflate(R.menu.contextmenu, menu);
		 info=(AdapterContextMenuInfo) menuInfo;
		 menu.setHeaderTitle(list.get(info.position).getName());
	}


  
    
}

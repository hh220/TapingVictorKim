package com.example.mytab;

public class PersonName {

	private String name;
	public PersonName(String name) {
		super();
		this.name = name;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}	
	
}
